﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    public static class Configuration
    {
        public const string CONNECTION_STRING = "Server=DESKTOP-27C392F;Database=FootballBookmakerSystemDB;Integrated Security=True;";
    }
}
