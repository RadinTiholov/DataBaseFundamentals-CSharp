﻿using P03_FootballBetting.Data;
using System;

namespace P03_FootballBetting
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            FootballBettingContext context = new FootballBettingContext();
            var color = new Data.Models.Color();
            color.Name = "Adad";

            context.Colors.Add(color);

            context.SaveChanges();
        }
    }
}
